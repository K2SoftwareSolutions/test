Configuration dockerConfig
{
    Import-DscResource -module cDscDocker

    Node localhost{

		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true
		}

        cDscDocker ExampleA
        {
        docker = "docker"
        Ensure = 'Present'
		Swarm = 'Active'
		SwarmURI = "SWMTKN-1-ETCETCETC"
		exposeApi = $true
		daemonInterface = "tcp://0.0.0.0:2375"

        }
    }
}

dockerConfig