#
# Example for calling class outside of DSC
#
using module cDscDocker
$instance = New-Object cDscDocker

$instance.Test()
$instance.CheckDocker()
$instance.CheckDockerProvider()
