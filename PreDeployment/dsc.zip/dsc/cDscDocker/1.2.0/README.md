# cDscDocker
Docker DSC resource for purpose of managing docker installation

[![N|Solid](https://www.powershellgallery.com/Content/Images/PackageDefaultIcon.png)](https://www.powershellgallery.com/packages/cDscDocker)

[Available in the PowerShellGallery](https://www.powershellgallery.com/packages/cDscDocker)

cDscDocker is a PowerShell V5 Resource for the sole purpose of managing Docker installation status via DSC.

```PowerShell
Install-Module -Name cDscDocker
```
Examples can be found in the \Examples directory; however to quickly summarize how to call after module installation:

```PowerShell
Configuration dockerConfig
{
    Import-DscResource -module cDscDocker

    Node localhost{

	LocalConfigurationManager
	{
		RebootNodeIfNeeded = $true
	}
        cDscDocker test
        {
        	docker = "docker" #key; mandatory
        	Ensure = 'Present' #mandatory field (Available options: Present, Absent)
            swarm = 'Active' #mandatory field (Available options: Active, Inactive)
            swarmToken = "SWMTKN-1-guidguidguidguidguidguidguidguid" #your swarm token here
            swarmURI = "192.168.1.100:2377" #IP address of manager node
			exposeApi = $true #this is a true or false value
			daemonInterface = 'tcp://0.0.0.0:2375' #must be full URI format mimicing a daemon.json key-value
            


        }
    }
}

dockerConfig
```

More to come; updates will reach the Powershell Gallery quicker than GitHub; however major revisions will be posted here as well.